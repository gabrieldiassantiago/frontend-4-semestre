/**
 * Defina `NEXT_PUBLIC_API_URL` com a URL pública da API (ex.: o App Service do Azure)
 * para o front funcionar fora da sua máquina, como no preview do v0 ou na Vercel.
 */
export const API_BASE_URL = (process.env.NEXT_PUBLIC_API_URL || "http://localhost:8080").replace(/\/$/, "")

export const WS_URL = API_BASE_URL.replace(/^http/, "ws") + "/ws"
